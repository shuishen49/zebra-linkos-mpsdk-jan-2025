/***********************************************
 CONFIDENTIAL AND PROPRIETARY
 The source code and other information contained herein is the confidential and the exclusive property of
 ZIH Corp. and is subject to the terms and conditions in your end user license agreement.
 Copyright ZIH Corp. 2015
 ALL RIGHTS RESERVED
 ***********************************************/

package com.zebra.testconnect;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AvailableDemosFragment extends Fragment {

    public static final String FRAGMENT_TAG = "available_demos_fragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.available_demos_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        if (!TabletConfigurationHelper.isTabletConfiguration(view.getContext()) || TabletConfigurationHelper.isPortraitConfiguration(view.getContext())) {
            view.findViewById(R.id.priceTagFileInfo).setVisibility(View.GONE);
            view.findViewById(R.id.receiptFileInfo).setVisibility(View.GONE);
        }

        LinearLayout priceTagLayout = view.findViewById(R.id.printPriceTagLayout);
        if (priceTagLayout != null) {
            priceTagLayout.setOnClickListener(v -> loadPrintDemoFragment(new PrintDemoShelfLabel(getActivity().getApplicationContext())));
        }

        LinearLayout receiptLayout = view.findViewById(R.id.printReceiptLayout);
        if (receiptLayout != null) {
            receiptLayout.setOnClickListener(v -> loadPrintDemoFragment(new PrintDemoReceipt(getActivity().getApplicationContext())));
        }
    }

    private void loadPrintDemoFragment(PrintDemo printDemo) {
        Bundle arguments = new Bundle();
        arguments.putSerializable(PrintDemoFragment.PRINT_DEMO_KEY, printDemo);

        PrintDemoFragment demoFragment = new PrintDemoFragment();
        demoFragment.setArguments(arguments);
        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentScrollViewLayout, demoFragment, PrintDemoFragment.FRAGMENT_TAG).commit();
    }

}
